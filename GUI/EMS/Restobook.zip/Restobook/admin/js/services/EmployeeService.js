angular.module('EmployeeService', []).factory('Employee', ['$http', function($http) {

	

}]);