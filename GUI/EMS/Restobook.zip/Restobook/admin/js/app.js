angular.module('RestobookApp', ['ngRoute', 'appRoutes','RestaurantsCtrl','CustomersCtrl', 'BookingCtrl','DashBoardCtrl' ,'OnlineOrderCtrl', 'EmployeeCtrl', 'EmployeeService', 'AdvertisementCtrl']);
var serviceDomain='http://localhost:8888/';
//var serviceDomain='http://182.18.152.39:8888/';