angular.module('ProductService', []).factory('Product', ['$http', function($http) {

	

}]);