angular.module('CustomerService', []).factory('Customer', ['$http', function($http) {

	

}]);